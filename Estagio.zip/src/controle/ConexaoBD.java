/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author kalar
 */
public class ConexaoBD {
    
    public Statement stm;//variável responsável para REALIZAR a pesquisa no banco de dados
    public ResultSet rs;//variável responsável por ARMAZENAR o resultado da pesquisa
    private String driver = "org.postgresql.Driver";//variável responsável para identificar nosso serviço no banco de dados (driver do postgre)
    //o caminho do driver é padrão do postgresql para acessar o driver
    private String caminho = "jdbc:postgresql://localhost:5433/cadastroClientes";//caminho do nosso banco de dados, onde ele está alocado
    //acima tem que ver se o caminho da porta é realmente 5433 ou 5432
    private String usuario = "postgres";//é usuário padrão do postgresql
    private String senha = "Edu.080514";//a senha que usou no banco de dados é a mesma que vai ser usada aqui
    public Connection con;//vai realizar a CONEXAO com o banco de dados
    
    public void conexao(){//novo método
        
        try {
            System.setProperty("jdbc.Drivers", driver);//responsável por "setar" ou conectar o driver de conexão
            con = DriverManager.getConnection(caminho, usuario, senha);//precisa circundar a instrução com tryCatch
            JOptionPane.showMessageDialog(null, "Conexão efetuada com sucesso!!");//esse "try" vai enviar uma mensagem pra tela se o usuario se conectar 
        } catch (SQLException ex) {
            /*Logger.getLogger(conexaoBD.class.getName()).log(Level.SEVERE, null, ex);*/
            JOptionPane.showMessageDialog(null, "Erro ao se conectar com o banco de dados:\n"+ex.getMessage());
            //se não conseguir se conectar vai aparecer essa mensagem e o "ex" vai mostrar o código do erro ("\n" é para pular linha)
        }    
    }
    
    public void desconecta(){//método responsável por desconectar o driver do banco de dados
        try {        
            con.close();
            JOptionPane.showMessageDialog(null, "Banco de dados desconectado com sucesso!!");
        } catch (SQLException ex) {
            //Logger.getLogger(conexaoBD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao fechar conexão com banco de dados:\n"+ex.getMessage());
        }
    }
}
